class GithubRepo {
  final String name;
  final String? description;
  final String? language;
  final String htmlUrl;

  GithubRepo({
    required this.name,
    this.description,
    this.language,
    required this.htmlUrl,
  });

  factory GithubRepo.fromJson(Map<String, dynamic> json) {
    return GithubRepo(
      name: json['name'] ?? '',
      description: json['description'],
      language: json['language'],
      htmlUrl: json['html_url'] ?? '',
    );
  }
}
