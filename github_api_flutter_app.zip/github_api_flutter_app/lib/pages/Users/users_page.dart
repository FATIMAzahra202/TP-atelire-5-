import 'package:flutter/material.dart';
import '../../services/github_service.dart';
import '../../models/github_user.dart';
import 'package:url_launcher/url_launcher.dart';

class UsersPage extends StatelessWidget {
  const UsersPage({super.key});

  void _openUser(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final GithubService githubService = GithubService();

    return Scaffold(
      appBar: AppBar(title: const Text("GitHub Users")),
      body: FutureBuilder<List<GithubUser>>(
        future: githubService.fetchUsers(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          final users = snapshot.data ?? [];

          return ListView.builder(
            itemCount: users.length,
            itemBuilder: (context, index) {
              final user = users[index];

              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(user.avatarUrl),
                  ),
                  title: Text(user.login),
                  onTap: () => _openUser(user.htmlUrl),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
