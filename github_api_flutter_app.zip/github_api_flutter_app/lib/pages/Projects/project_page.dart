import 'package:flutter/material.dart';
import '../../services/github_service.dart';
import '../../models/github_repo.dart';
import 'package:url_launcher/url_launcher.dart';

class ProjectPage extends StatefulWidget {
  const ProjectPage({super.key});

  @override
  State<ProjectPage> createState() => _ProjectPageState();
}

class _ProjectPageState extends State<ProjectPage> {
  final GithubService _githubService = GithubService();
  late Future<List<GithubRepo>> _futureRepos;

  @override
  void initState() {
    super.initState();
    _futureRepos = _githubService.fetchUserRepos("saidouchrif");
  }

  void _openRepo(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("GitHub Projects")),
      body: FutureBuilder<List<GithubRepo>>(
        future: _futureRepos,
        builder: (context, snapshot) {
          // ---------------------------
          // 🔄 Loading
          // ---------------------------
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          // ---------------------------
          // ❌ Error
          // ---------------------------
          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          // ---------------------------
          // ✅ Data OK
          // ---------------------------
          final repos = snapshot.data ?? [];

          if (repos.isEmpty) {
            return const Center(child: Text("No repositories found"));
          }

          return ListView.builder(
            itemCount: repos.length,
            itemBuilder: (context, index) {
              final repo = repos[index];

              return Card(
                margin: const EdgeInsets.all(10),
                elevation: 3,
                child: ListTile(
                  title: Text(repo.name),
                  subtitle: Text(repo.description ?? "No description"),
                  trailing: Text(repo.language ?? "N/A"),
                  onTap: () => _openRepo(repo.htmlUrl),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
