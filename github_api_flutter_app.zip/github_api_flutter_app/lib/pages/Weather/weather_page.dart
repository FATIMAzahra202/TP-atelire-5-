import 'package:flutter/material.dart';
import '../../services/weather_service.dart';

class WeatherPage extends StatefulWidget {
  const WeatherPage({super.key});

  @override
  State<WeatherPage> createState() => _WeatherPageState();
}

class _WeatherPageState extends State<WeatherPage> {
  final TextEditingController cityCtrl = TextEditingController();
  final WeatherService weatherService = WeatherService();

  Map<String, dynamic>? weatherData;
  bool isLoading = false;
  String? error;

  void searchWeather() async {
    final city = cityCtrl.text.trim();
    if (city.isEmpty) return;

    setState(() {
      isLoading = true;
      error = null;
    });

    try {
      final data = await weatherService.fetchWeather(city);
      setState(() {
        weatherData = data;
      });
    } catch (e) {
      setState(() {
        error = "Ville introuvable ❌";
        weatherData = null;
      });
    }

    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Weather ☁️")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: cityCtrl,
              decoration: InputDecoration(
                labelText: "Ville",
                hintText: "Ex: Paris, Casablanca...",
                suffixIcon: IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: searchWeather,
                ),
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),

            if (isLoading) const CircularProgressIndicator(),
            if (error != null)
              Text(error!, style: const TextStyle(color: Colors.red)),

            if (weatherData != null) ...[
              const SizedBox(height: 20),

              Text(
                "${weatherData!["name"]}",
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 10),

              Text(
                "${weatherData!["main"]["temp"]}°C",
                style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 10),

              Text(
                weatherData!["weather"][0]["description"],
                style: const TextStyle(fontSize: 18),
              ),

              const SizedBox(height: 10),

              Image.network(
                "https://openweathermap.org/img/wn/${weatherData!["weather"][0]["icon"]}@4x.png",
                width: 120,
                height: 120,
              ),

              const SizedBox(height: 10),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text("Humidité: ${weatherData!["main"]["humidity"]}%"),
                  Text("Vent: ${weatherData!["wind"]["speed"]} m/s"),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
