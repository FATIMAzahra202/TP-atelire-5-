import 'package:flutter/material.dart';
import 'contact_add.dart';
import 'contact_update.dart';

class ContactPage extends StatefulWidget {
  const ContactPage({super.key});

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  List<Map<String, String>> contacts = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Contacts")),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const ContactAddPage()),
          );
          if (result != null) {
            setState(() => contacts.add(result));
          }
        },
        child: const Icon(Icons.add),
      ),
      body: contacts.isEmpty
          ? const Center(child: Text("No contacts"))
          : ListView.builder(
              itemCount: contacts.length,
              itemBuilder: (context, index) {
                final c = contacts[index];
                return ListTile(
                  title: Text(c["name"]!),
                  subtitle: Text(c["email"]!),
                  trailing: IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () async {
                      final updated = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              ContactUpdatePage(contact: c),
                        ),
                      );
                      if (updated != null) {
                        setState(() => contacts[index] = updated);
                      }
                    },
                  ),
                );
              },
            ),
    );
  }
}
