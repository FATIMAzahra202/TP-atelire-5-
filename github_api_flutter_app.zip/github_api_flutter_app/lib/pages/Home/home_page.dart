import 'package:flutter/material.dart';

import '../Projects/project_page.dart';
import '../Users/users_page.dart';
import '../Posts/posts_page.dart';
import '../Weather/weather_page.dart';
import '../Settings/settings_page.dart';
import '../Contact/contact_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  void _openPage(BuildContext context, Widget page) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("GitHub Explorer"),
      ),

      // ------------------ Drawer ------------------
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Colors.blue,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircleAvatar(
                    radius: 40,
                    backgroundImage: AssetImage("images/profile.png"),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Fatima zahra Mgh",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            ListTile(
              leading: const Icon(Icons.home),
              title: const Text("Home"),
              onTap: () => Navigator.pop(context),
            ),

            ListTile(
              leading: const Icon(Icons.code),
              title: const Text("Projects"),
              onTap: () => _openPage(context, ProjectPage()),
            ),

            ListTile(
              leading: const Icon(Icons.people),
              title: const Text("Users"),
              onTap: () => _openPage(context, UsersPage()),
            ),

            ListTile(
              leading: const Icon(Icons.article),
              title: const Text("Posts"),
              onTap: () => _openPage(context, PostsPage()),
            ),

            // -------- Weather Page 🔥 --------
            ListTile(
              leading: const Icon(Icons.cloud),
              title: const Text("Weather"),
              onTap: () => _openPage(context, WeatherPage()),
            ),

            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text("Settings"),
              onTap: () => _openPage(context, SettingsPage()),
            ),

            ListTile(
              leading: const Icon(Icons.contact_mail),
              title: const Text("Contact"),
              onTap: () => _openPage(context, ContactPage()),
            ),
          ],
        ),
      ),

      // ------------------ Body ------------------
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.blue.withOpacity(0.2),
                Colors.blue.withOpacity(0.05),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Text(
            "Welcome to GitHub Explorer 👋",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}
