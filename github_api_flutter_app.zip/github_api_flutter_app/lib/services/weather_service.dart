import 'dart:convert';
import 'package:http/http.dart' as http;

class WeatherService {
  final String apiKey = "d1c67704f35a14487bbf7f2ae6400b30";

  Future<Map<String, dynamic>> fetchWeather(String city) async {
    final url =
        "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric&lang=fr";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception("City not found");
    }
  }
}
