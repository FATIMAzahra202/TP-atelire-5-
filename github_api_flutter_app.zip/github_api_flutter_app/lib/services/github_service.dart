import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/github_user.dart';
import '../models/github_repo.dart';

class GithubService {
  static const _baseUrl = 'https://api.github.com';
  static const _headers = {
    'Accept': 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
  };

  Future<List<GithubUser>> fetchUsers({int perPage = 30}) async {
    final uri = Uri.parse('$_baseUrl/users?per_page=$perPage');
    final response = await http.get(uri, headers: _headers);

    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((e) => GithubUser.fromJson(e)).toList();
    } else {
      throw Exception('Failed to load users');
    }
  }

  Future<List<GithubRepo>> fetchUserRepos(String username) async {
    final uri = Uri.parse('$_baseUrl/users/$username/repos');
    final response = await http.get(uri, headers: _headers);

    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((e) => GithubRepo.fromJson(e)).toList();
    } else {
      throw Exception('Failed to load repos for $username');
    }
  }
}
